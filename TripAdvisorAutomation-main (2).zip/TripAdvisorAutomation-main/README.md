# TripAdvisorAutomation

### Detailed Description: Hackath Ideas
- Display Hotel name, total amount and charges per night for 3 holiday homes for 4 people in Nairobi for 5 days of stay from tomorrow's date; Should have sorted the list with highest traveler rating & should have elevator/ Lift  access
- Pick one cruise line & pick a respective cruise ship under Cruises; 
  - Retrieve all the languages offered and store in a List; Display the same
  - Display passengers, crew & launched year

### Key Automation Scope
- Handling different browser windows, search option
- Validation of date controls
- Capture warning message
- Extract list items & store in collections
- Navigating back to home page
- Scrolling down in web page
